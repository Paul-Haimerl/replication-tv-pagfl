## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib PAGFLReplication, .registration = TRUE
## usethis namespace: end
NULL
## usethis namespace: start
#' @useDynLib PAGFLReplication, .registration = TRUE
## usethis namespace: end
NULL
## usethis namespace: start
#' @importFrom RcppParallel RcppParallelLibs
## usethis namespace: end
NULL
