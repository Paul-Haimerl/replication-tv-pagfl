#' B-spline basis
#'
#' @description Construct a system of B-spline basis functions
#'
#' @param x a numeric vector of support.
#' @param d the polynomial degree. Default is 3 for cubic splines.
#' @param M the number of interior knots. Default is 3.
#' @param intercept logical. If TRUE, an intercept is added. Default is TRUE.
#'
#' @examples
#' b <- create_bspline_system(1:100, d = 3, M = 2)
#' head(b)
#'
#' @author Paul Haimerl
#'
#' @return A matrix of the spline basis functions.
#'
#' @export
create_bspline_system <- function(x, d = 3, M = 3, intercept = TRUE) {
  knots <- seq(x[1], length(x), length.out = 2 + M)
  b <- bspline_system(x = x, d = d, knots = knots, intercept = intercept)
  return(b)
}
