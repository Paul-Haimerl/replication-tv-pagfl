#' Demean a numeric vector by demeaning sub-vectors
#'
#' @param x a numeric vector
#' @param N the number of sub-vectors
#' @param i_index An vector of integers identifying each subvector, e.g. i_index = c(1, 1, 2, 2, 2, 3, 3, ...)
#'
#' @author Paul Haimerl
#'
#' @return A demeaned vector.
#'
#' @export
demean_vec <- function(x, N, i_index){
  demeanIndVec(x = x, N = N, i_index = i_index)
}
