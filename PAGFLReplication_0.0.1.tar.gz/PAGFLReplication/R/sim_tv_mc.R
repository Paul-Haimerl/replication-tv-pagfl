#' Simulate a Time-varying Panel With a Group Structure in the Slope Coefficients
#'
#' @description Construct a time-varying panel data set subject to a group structure in the slope coefficients according to Haimerl et al. (2025, sec. 4.1).
#'
#' @param N the number of cross-sectional units. Default is 50.
#' @param n_periods the number of simulated time periods \eqn{T}. Default is 40.
#' @param DGP the data generating process according to Haimerl et al. (2025, sec. 4.1)
#' #' \describe{
#' \item{\code{1}}{for a trending panel data model.}
#' \item{\code{2}}{for a trending panel data model with an additional exogenous regressor.}
#' \item{\code{3}}{for dynamic panel data model.}
#' }
#' @param sd_error standard deviation of the cross-sectional errors. Default is 1.
#' @param AR_errors Logical. If true, the innovations follow an AR(1) with a 0.3 lag coefficient. Default is FALSE.
#'
#' @examples
#' set.seed(1)
#' sim <- sim_tv_DGP(N = 10, n_periods = 50, DGP = 1)
#' df <- data.frame(y = c(sim$y))
#'
#' @author Paul Haimerl
#'
#' @return A list holding
#' \item{\code{alpha}}{a \eqn{T \times p \times K} array of group-specific time-varying parameters}
#' \item{\code{beta}}{a \eqn{T \times p \times N} array of individual time-varying parameters}
#' \item{\code{groups}}{a vector indicating the group memberships \eqn{(g_1, \dots, g_N)}, where \eqn{g_i = k} if \eqn{i \in} group \eqn{k}.}
#' \item{\code{y}}{a \eqn{NT \times 1} vector of the dependent variable, with \eqn{\bold{y}=(y_1, \dots, y_N)^\prime}, \eqn{y_i = (y_{i1}, \dots, y_{iT})^\prime} and the scalar \eqn{y_{it}}.}
#' \item{\code{X}}{a \eqn{NT \times p} matrix of explanatory variables, with \eqn{\bold{X}=(x_1, \dots, x_N)^\prime}, \eqn{x_i = (x_{i1}, \dots, x_{iT})^\prime} and the \eqn{p \times 1} vector \eqn{x_{it}}.}
#'
#' @export
sim_tv_paper <- function(N = 50, n_periods = 40, DGP = 1, sd_error = 1, AR_errors = FALSE) {
  #------------------------------#
  #### Checks                 ####
  #------------------------------#

  if (!(DGP %in% 1:3)) stop("Select on of the DGPs 1 to 3\n")

  #------------------------------#
  #### Generate parameters    ####
  #------------------------------#


  if (DGP != 3) {
    # Time trends
    locations <- c(.5, .7, .6)
    scales <- c(.1, .05, .05)
    trend_mat <- trend_fctn(coef_mat = cbind(locations, scales), n_periods = n_periods)
    trend_mat[, 2] <- trend_mat[, 2] + poly_fctn(coef_mat = t(c(2, -6, 4)), n_periods = n_periods)
    trend_mat[, 3] <- trend_mat[, 3] + poly_fctn(coef_mat = t(c(4, -8, 4)), n_periods = n_periods)
    trend_mat <- 6 * trend_mat
  }

  # Polynomial coefficients
  alpha_coef <- array(c(
    2, -4, 2, 1, -3, 2, .5, -.5, 0,
    2, -5, 2, 1, -3, 2, .5, -.5, 0
  ), dim = c(3, 3, 2))
  trend_coef <- array(c(
    .6, .7, .4, .1, .04, .07,
    .6, .2, .8, .03, .04, .07
  ), dim = c(3, 2, 2))

  if (DGP == 2) {
    p <- 2
  } else {
    p <- 1
  }

  n_groups <- 3
  alpha_array <- array(NA, dim = c(n_periods, p, n_groups))

  for (k in 1:n_groups) {
    if (DGP == 2) {
      trend_mat_star <- trend_fctn(coef_mat = t(trend_coef[k, , 1]), n_periods = n_periods)
      poly_coef <- t(alpha_coef[, k, 1])
      alpha_mat <- poly_fctn(coef_mat = poly_coef, n_periods = n_periods)
      trend_coef_mat <- alpha_mat + trend_mat_star
      alpha_array[, , k] <- cbind(.5 * trend_mat[, k], 3 * trend_coef_mat)
    } else if (DGP == 3) {
      trend_mat_star <- trend_fctn(coef_mat = t(trend_coef[k, , 2]), n_periods = n_periods)
      poly_coef <- t(alpha_coef[, k, 2])
      alpha_mat <- poly_fctn(coef_mat = poly_coef, n_periods = n_periods)
      trend_coef_mat <- -.5 + alpha_mat + trend_mat_star
      alpha_array[, , k] <- 3 / 2 * trend_coef_mat
    } else {
      alpha_array[, , k] <- trend_mat[, k]
    }
  }

  #------------------------------#
  #### Simulate the groupings ####
  #------------------------------#

  group_vec <- rep(1:n_groups, round(c(.3, .3, .4) * N))
  if (length(group_vec) != N) group_vec <- rep(group_vec, length.out = N)
  groups_raw <- sample(group_vec, N, replace = FALSE)
  groups <- match(groups_raw, unique(groups_raw))
  beta_array <- alpha_array[, , groups]
  if (is.matrix(beta_array)) {
    beta_array <- array(beta_array, dim = c(n_periods, 1, N))
  }
  beta_mat <- matrix(aperm(beta_array, c(1, 3, 2)), ncol = dim(beta_array)[2])

  #------------------------------#
  #### Construct X and y      ####
  #------------------------------#

  # Draw the fixed effects
  gamma <- rep(stats::rnorm(N), each = n_periods)
  # Generate the regressors
  if (DGP != 3) {
    # Draw the cross-sectional errors
    if (AR_errors) {
      u <- c(sapply(1:N, function(i) stats::filter(stats::rnorm(n_periods, sd = sd_error), filter = .4, method = "recursive")))
    } else {
      u <- stats::rnorm(N * n_periods, sd = sd_error)
    }

    if (DGP == 1) {
      X <- as.matrix(rep(1, N * n_periods))
      # Construct the observations
      y <- X * beta_mat + gamma + u
    } else if (DGP == 2) {
      X <- cbind(rep(1, N * n_periods), stats::rnorm(N * n_periods))
      # Construct the observations
      y <- rowSums(X * beta_mat) + gamma + u
    }
  } else {
    # Draw the cross-sectional errors
    if (AR_errors) {
      u <- matrix(c(sapply(1:N, function(i) stats::filter(stats::rnorm(n_periods + 1, sd = sd_error), filter = .3, method = "recursive"))), ncol = N)
    } else {
      u <- matrix(stats::rnorm(N * (n_periods + 1), sd = sd_error), ncol = N)
    }
    y <- c()
    X <- c()
    for (i in 1:N) {
      gamma_i <- unique(gamma)[i]
      y_i <- rep(0, n_periods + 1)
      y_i[1] <- gamma_i + u[1, i]
      for (t in 2:(n_periods + 1)) {
        y_i[t] <- y_i[t - 1] * alpha_array[t - 1, , groups[i]] + gamma_i + u[t, i]
      }
      y <- c(y, y_i[-1])
      X <- c(X, y_i[-(n_periods + 1)])
    }
    y <- as.matrix(y)
    X <- as.matrix(X)
  }

  if (DGP == 2) {
    X <- as.matrix(X[, -1])
  } else if (DGP == 1) {
    X <- NULL
  }

  return(list(alpha = alpha_array, beta = beta_array, groups = groups, y = y, X = X))
}
